"use strict";
(() => {
  // extension/src/domain/rules.ts
  function classifyGroup(label) {
    if (/教育|学习经历|学历|学位/.test(label)) return "education";
    if (/项目/.test(label)) return "projects";
    if (/实习|工作经历|任职/.test(label)) return "experience";
    if (/技能|技术栈/.test(label)) return "skills";
    if (/个人|基本|联系/.test(label)) return "basic";
    return "other";
  }
  var blockedLabel = (text) => /密码|验证码|校验码|身份证|证件号|护照|银行卡|信用卡|银行账户|承诺|声明|同意|隐私|协议|授权|调剂|password|passcode|one.?time|otp|captcha|passport|credit.?card|bank.?account|consent|agreement/i.test(text);

  // extension/src/content/site-adapters.ts
  function siteField(node, readLabel) {
    if (location.hostname !== "jobs.lever.co" || !/^\/[^/]+\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\/apply\/?$/i.test(location.pathname)) return null;
    const form = node.closest("form#application-form");
    const question = node.closest(".application-question");
    if (!form || !question || question.closest("form") !== form || !node.closest(".application-field")) return null;
    const labels = Array.from(question.querySelectorAll(".application-label")).filter((label2) => label2.closest(".application-question") === question);
    if (labels.length !== 1) return null;
    const label = readLabel(labels[0]).replace(/\s+/g, " ").trim().slice(0, 120);
    if (!label) return null;
    return { label, ...node.matches('input#location-input[name="location"]') ? { blocked: "\u4F4D\u7F6E\u9700\u8981\u4ECE\u7F51\u7AD9\u641C\u7D22\u7ED3\u679C\u4E2D\u9009\u62E9\uFF0C\u8BF7\u624B\u52A8\u5904\u7406" } : {} };
  }

  // extension/src/content/engine.ts
  var wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  var compact = (s, max = 120) => (s ?? "").replace(/\s+/g, " ").trim().slice(0, max);
  function visible(el) {
    if (!el.isConnected || el.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    const style = getComputedStyle(el);
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && el.getClientRects().length > 0;
  }
  function labelText(el) {
    if (!el) return "";
    const clone = el.cloneNode(true);
    clone.querySelectorAll('input,select,textarea,button,script,style,[aria-hidden="true"]').forEach((child) => child.remove());
    return clone.textContent ?? "";
  }
  function ownLabel(el) {
    const labels = "labels" in el ? el.labels : null;
    const described = (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).map((id) => labelText(document.getElementById(id))).join(" ");
    return compact(labels?.length ? Array.from(labels).map(labelText).join(" ") : el.getAttribute("aria-label") || described || el.getAttribute("placeholder") || el.getAttribute("name") || el.id || "\u672A\u547D\u540D\u5B57\u6BB5");
  }
  function groupFor(el) {
    let fallback = null;
    for (let parent = el.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      if (!parent.matches("fieldset,section,[data-resume-group]")) continue;
      fallback ??= parent;
      const title = compact(parent.querySelector(":scope > legend, :scope > h2, :scope > h3, :scope > .section-title")?.textContent || parent.getAttribute("aria-label"));
      const section = classifyGroup(title);
      if (section !== "other") return { root: parent, label: title, section };
    }
    const root = fallback ?? el.closest("form") ?? document.body;
    return { root, label: compact(root.querySelector(":scope > legend, :scope > h2, :scope > h3")?.textContent) || "\u5F53\u524D\u8868\u5355", section: "other" };
  }
  function read(t) {
    if (t.radios) return t.radios.find((r) => r.checked)?.value ?? "";
    if (t.node instanceof HTMLInputElement && t.node.type === "checkbox") return t.node.checked;
    return t.node.value;
  }
  var FormEngine = class {
    pageToken = crypto.randomUUID();
    sessionId = "";
    url = "";
    targets = [];
    groupIds = /* @__PURE__ */ new WeakMap();
    completed = /* @__PURE__ */ new Map();
    undoLog = [];
    busy = false;
    describe(node, radios) {
      const kind = node instanceof HTMLInputElement ? node.type : node instanceof HTMLSelectElement ? node.type : node instanceof HTMLTextAreaElement ? "textarea" : "custom";
      const group = groupFor(node);
      let groupId = this.groupIds.get(group.root);
      if (!groupId) {
        groupId = crypto.randomUUID();
        this.groupIds.set(group.root, groupId);
      }
      const radioLegend = radios ? compact(node.closest("fieldset")?.querySelector(":scope > legend")?.textContent) : "";
      const site = siteField(node, labelText);
      const label = kind !== "checkbox" && site ? site.label : radios ? compact(node.getAttribute("data-group-label") || (radioLegend && classifyGroup(radioLegend) === "other" ? radioLegend : "") || node.getAttribute("name")) : ownLabel(node);
      const safetyText = [label, site?.label, node.id, node.getAttribute("name"), node.getAttribute("autocomplete"), node.getAttribute("aria-label")].join(" ");
      let blocked = null;
      if (blockedLabel(safetyText) || /(?:^|\s)(?:cc-|one-time-code)/.test(safetyText)) blocked = "\u654F\u611F\u4FE1\u606F\u3001\u9A8C\u8BC1\u6216\u58F0\u660E\u9879\uFF0C\u8BF7\u624B\u52A8\u5904\u7406";
      else if (site?.blocked) blocked = site.blocked;
      else if (!["text", "email", "tel", "textarea", "select-one", "radio", "date", "month", "checkbox"].includes(kind)) blocked = "\u5F53\u524D\u7248\u672C\u4E0D\u652F\u6301\u6B64\u63A7\u4EF6\uFF0C\u8BF7\u624B\u52A8\u586B\u5199";
      else if (node.matches(":disabled") || node.readOnly || node.getAttribute("aria-disabled") === "true") blocked = "\u6B64\u5B57\u6BB5\u4E0D\u53EF\u7F16\u8F91";
      else if (node.hasAttribute("role") && node.getAttribute("role") === "combobox" && !(node instanceof HTMLSelectElement)) blocked = "\u81EA\u5B9A\u4E49\u4E0B\u62C9\u6846\u9700\u8981\u4E13\u7528\u9002\u914D\uFF0C\u8BF7\u624B\u52A8\u9009\u62E9";
      else if (kind === "checkbox" && group.section !== "skills") blocked = "\u53EA\u652F\u6301\u660E\u786E\u7684\u6280\u80FD\u590D\u9009\u9879\uFF0C\u5176\u4ED6\u9009\u9879\u8BF7\u624B\u52A8\u52FE\u9009";
      const options = node instanceof HTMLSelectElement ? Array.from(node.options).filter((o) => !o.disabled && !o.closest("optgroup[disabled]") && o.value !== "").map((o) => ({ label: compact(o.label), value: o.value })) : radios?.filter((r) => visible(r) && !r.matches(":disabled") && !blockedLabel(ownLabel(r))).map((r) => ({ label: ownLabel(r), value: r.value })) ?? [];
      const field = {
        id: "",
        label,
        kind,
        groupId,
        groupLabel: group.label,
        section: group.section,
        currentValue: null,
        options,
        maxLength: "maxLength" in node ? node.maxLength : -1,
        required: "required" in node && node.required || node.getAttribute("aria-required") === "true",
        blocked
      };
      const signature = JSON.stringify({ ...field, min: node.getAttribute("min"), max: node.getAttribute("max"), pattern: node.getAttribute("pattern"), autocomplete: node.getAttribute("autocomplete") });
      const target = { node, radios, field, signature };
      if (!blocked) field.currentValue = read(target);
      return target;
    }
    collect() {
      const all = Array.from(document.querySelectorAll('input,textarea,select,[role="combobox"],[contenteditable="true"]')).filter((el) => visible(el) && !(el instanceof HTMLInputElement && ["hidden", "submit", "button", "reset", "image"].includes(el.type)));
      const seen = /* @__PURE__ */ new Set();
      const targets = [];
      for (const node of all) {
        if (seen.has(node)) continue;
        if (node instanceof HTMLInputElement && node.type === "radio" && node.name) {
          const radios = all.filter((el) => el instanceof HTMLInputElement && el.type === "radio" && el.name === node.name && el.form === node.form);
          radios.forEach((r) => seen.add(r));
          targets.push(this.describe(node, radios));
        } else {
          seen.add(node);
          targets.push(this.describe(node));
        }
      }
      return targets;
    }
    scan() {
      if (this.busy) throw new Error("\u586B\u5199\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u65B0\u626B\u63CF");
      this.targets = this.collect();
      if (this.targets.length > 300) {
        this.targets = [];
        throw new Error("\u5F53\u524D\u9875\u5B57\u6BB5\u8D85\u8FC7 300 \u4E2A\uFF0C\u8BF7\u5C55\u5F00\u9700\u8981\u586B\u5199\u7684\u680F\u76EE\u540E\u518D\u626B\u63CF");
      }
      this.targets.forEach((t) => {
        t.field.id = crypto.randomUUID();
      });
      this.sessionId = crypto.randomUUID();
      this.url = location.href;
      this.completed.clear();
      this.undoLog = [];
      const notices = [];
      if (document.querySelector("iframe")) notices.push("\u5D4C\u5165\u9875\u9762\u4E2D\u7684\u8868\u5355\u5C1A\u672A\u626B\u63CF\uFF0C\u8BF7\u81EA\u884C\u68C0\u67E5\u3002");
      if (Array.from(document.querySelectorAll("*")).some((el) => el.shadowRoot)) notices.push("Shadow DOM \u5185\u7684\u63A7\u4EF6\u6682\u9700\u624B\u52A8\u5904\u7406\u3002");
      return { sessionId: this.sessionId, pageToken: this.pageToken, url: this.url, fields: this.targets.map((t) => t.field), notices };
    }
    assertSession(req) {
      if (!this.sessionId || req.sessionId !== this.sessionId || req.pageToken !== this.pageToken || location.href !== this.url) throw new Error("\u9875\u9762\u6216\u626B\u63CF\u7ED3\u679C\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF");
    }
    assertStructure() {
      const fresh = this.collect();
      if (fresh.length !== this.targets.length || fresh.some((t, i) => t.node !== this.targets[i].node || t.signature !== this.targets[i].signature || t.radios?.some((r, j) => r !== this.targets[i].radios?.[j]))) {
        throw new Error("\u8868\u5355\u7ED3\u6784\u6216\u5B57\u6BB5\u542B\u4E49\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF");
      }
    }
    setValue(target, value) {
      const el = target.node;
      let eventNode = el;
      if (target.radios) {
        if (typeof value !== "string") throw new Error("\u9009\u9879\u683C\u5F0F\u9519\u8BEF");
        const selected = target.radios.find((r) => r.value === value && visible(r) && !r.matches(":disabled"));
        if (value && !selected) throw new Error("\u9009\u9879\u5DF2\u4E0D\u5B58\u5728");
        for (const r of target.radios) Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked").set.call(r, r === selected);
        eventNode = selected ?? el;
      } else if (el instanceof HTMLInputElement && el.type === "checkbox") {
        if (typeof value !== "boolean") throw new Error("\u590D\u9009\u9879\u683C\u5F0F\u9519\u8BEF");
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked").set.call(el, value);
      } else {
        if (typeof value !== "string") throw new Error("\u5B57\u6BB5\u503C\u683C\u5F0F\u9519\u8BEF");
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
      }
      eventNode.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      eventNode.dispatchEvent(new Event("change", { bubbles: true }));
    }
    async fill(req) {
      this.assertSession(req);
      if (this.completed.has(req.operationId)) return this.completed.get(req.operationId);
      if (this.busy) throw new Error("\u586B\u5199\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u52FF\u91CD\u590D\u64CD\u4F5C");
      if (!Array.isArray(req.operations) || req.operations.length > 300 || typeof req.operationId !== "string" || req.operationId.length > 100) throw new Error("\u65E0\u6548\u7684\u586B\u5199\u8BA1\u5212");
      this.assertStructure();
      const ids = /* @__PURE__ */ new Set();
      for (const op of req.operations) {
        const target = this.targets.find((t) => t.field.id === op.fieldId);
        if (!target || ids.has(op.fieldId) || target.field.blocked || !["string", "boolean"].includes(typeof op.value) || typeof op.value === "string" && op.value.length > 1e4) throw new Error("\u586B\u5199\u8BA1\u5212\u542B\u65E0\u6548\u3001\u53D7\u9650\u6216\u91CD\u590D\u5B57\u6BB5");
        ids.add(op.fieldId);
        if (target.field.kind === "checkbox" && (target.field.section !== "skills" || op.value !== true)) throw new Error("\u590D\u9009\u6846\u53EA\u5141\u8BB8\u786E\u8BA4\u5DF2\u638C\u63E1\u7684\u6280\u80FD");
      }
      this.busy = true;
      this.undoLog = [];
      const results = [];
      try {
        for (const op of req.operations) {
          const t = this.targets.find((t2) => t2.field.id === op.fieldId);
          try {
            this.assertSession(req);
            this.assertStructure();
            if (read(t) !== op.expectedValue) {
              results.push({ fieldId: op.fieldId, status: "skipped", message: "\u9884\u89C8\u540E\u5185\u5BB9\u5DF2\u88AB\u4FEE\u6539\uFF0C\u4FDD\u7559\u5F53\u524D\u503C" });
              continue;
            }
            if (typeof op.value === "string" && t.field.maxLength >= 0 && op.value.length > t.field.maxLength) throw new Error("\u5185\u5BB9\u8D85\u8FC7\u7F51\u9875\u957F\u5EA6\u9650\u5236");
            if (t.field.kind === "date" && (typeof op.value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(op.value))) throw new Error("\u7F51\u9875\u9700\u8981\u5B8C\u6574\u65E5\u671F\uFF0C\u4E0D\u4F1A\u8865\u9020\u65E5\u671F");
            if (["select-one", "radio"].includes(t.field.kind) && !t.field.options.some((o) => o.value === op.value)) throw new Error("\u7F51\u9875\u9009\u9879\u5DF2\u53D8\u5316");
            const oldValue = read(t);
            this.setValue(t, op.value);
            this.undoLog.push({ target: t, oldValue, written: op.value });
            await wait(35);
            this.assertSession(req);
            if (!t.node.isConnected || read(t) !== op.value) throw new Error("\u9875\u9762\u672A\u4FDD\u7559\u586B\u5199\u503C\uFF0C\u8BF7\u624B\u52A8\u68C0\u67E5");
            if ("validity" in t.node && !t.node.validity.valid) {
              if (read(t) === op.value) this.setValue(t, oldValue);
              throw new Error("\u672A\u901A\u8FC7\u7F51\u9875\u5B57\u6BB5\u6821\u9A8C\uFF0C\u5DF2\u5C1D\u8BD5\u6062\u590D\u539F\u503C");
            }
            results.push({ fieldId: op.fieldId, status: "filled", message: "\u5DF2\u586B\u5199\u5E76\u56DE\u8BFB\u786E\u8BA4" });
          } catch (error) {
            results.push({ fieldId: op.fieldId, status: "failed", message: error instanceof Error ? error.message : "\u586B\u5199\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u9875\u9762" });
            try {
              this.assertSession(req);
              this.assertStructure();
            } catch {
              break;
            }
          }
        }
        await wait(60);
        for (const result of results) if (result.status === "filled") {
          const op = req.operations.find((o) => o.fieldId === result.fieldId);
          const t = this.targets.find((t2) => t2.field.id === result.fieldId);
          if (location.href !== this.url || !t.node.isConnected || read(t) !== op.value) {
            result.status = "failed";
            result.message = "\u9875\u9762\u968F\u540E\u4FEE\u6539\u4E86\u5185\u5BB9\uFF0C\u8BF7\u624B\u52A8\u68C0\u67E5";
          }
        }
        for (const op of req.operations) if (!results.some((r) => r.fieldId === op.fieldId)) results.push({ fieldId: op.fieldId, status: "skipped", message: "\u8868\u5355\u5DF2\u53D8\u5316\uFF0C\u540E\u7EED\u586B\u5199\u5DF2\u505C\u6B62" });
        this.completed.set(req.operationId, results);
        return results;
      } finally {
        this.busy = false;
      }
    }
    async undo(req) {
      this.assertSession(req);
      if (this.busy) throw new Error("\u586B\u5199\u6B63\u5728\u8FDB\u884C");
      this.assertStructure();
      this.busy = true;
      const results = [];
      try {
        for (const { target: t, oldValue, written } of [...this.undoLog].reverse()) {
          try {
            this.assertSession(req);
            this.assertStructure();
            if (read(t) !== written) {
              results.push({ fieldId: t.field.id, status: "skipped", message: "\u6B64\u9879\u5DF2\u88AB\u7EE7\u7EED\u4FEE\u6539\uFF0C\u4FDD\u7559\u5F53\u524D\u5185\u5BB9" });
              continue;
            }
            this.setValue(t, oldValue);
            await wait(35);
            results.push({ fieldId: t.field.id, status: read(t) === oldValue ? "undone" : "failed", message: read(t) === oldValue ? "\u5DF2\u6062\u590D\u586B\u5199\u524D\u7684\u503C" : "\u9875\u9762\u672A\u4FDD\u7559\u6062\u590D\u503C" });
          } catch {
            results.push({ fieldId: t.field.id, status: "skipped", message: "\u76EE\u6807\u5DF2\u53D8\u5316\uFF0C\u672A\u64A4\u9500\u6B64\u9879" });
          }
        }
        this.undoLog = [];
        return results;
      } finally {
        this.busy = false;
      }
    }
    focus(req) {
      this.assertSession(req);
      this.assertStructure();
      const target = this.targets.find((t) => t.field.id === req.fieldId);
      if (!target) throw new Error("\u627E\u4E0D\u5230\u8BE5\u5B57\u6BB5");
      target.node.scrollIntoView({ behavior: "smooth", block: "center" });
      target.node.focus({ preventScroll: true });
    }
  };

  // extension/src/domain/types.ts
  var trustedPage = (sender) => {
    if (sender.id !== chrome.runtime.id || !sender.url) return false;
    try {
      const url = new URL(sender.url);
      return url.protocol === "chrome-extension:" && url.hostname === chrome.runtime.id && ["/options.html", "/sidepanel.html", "/connection.html"].includes(url.pathname);
    } catch {
      return false;
    }
  };

  // extension/src/content/index.ts
  if (!window.__resumeCompanionInstalled) {
    window.__resumeCompanionInstalled = true;
    const engine = new FormEngine();
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (!trustedPage(sender) || !message || !["SCAN", "FILL", "UNDO", "FOCUS"].includes(message.type)) return false;
      (async () => {
        switch (message.type) {
          case "SCAN":
            return engine.scan();
          case "FILL":
            return engine.fill(message);
          case "UNDO":
            return engine.undo(message);
          case "FOCUS":
            return engine.focus(message);
        }
      })().then((data) => respond({ ok: true, data }), (error) => respond({ ok: false, error: error instanceof Error ? error.message : "\u9875\u9762\u64CD\u4F5C\u5931\u8D25" }));
      return true;
    });
  }
})();
